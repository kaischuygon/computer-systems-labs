/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_297()
{
    return 3284633928U;
}

void setval_190(unsigned *p)
{
    *p = 2109986823U;
}

unsigned addval_118(unsigned x)
{
    return x + 2428995912U;
}

void setval_256(unsigned *p)
{
    *p = 3281031240U;
}

unsigned addval_235(unsigned x)
{
    return x + 2445773128U;
}

unsigned getval_492()
{
    return 3277358039U;
}

unsigned getval_445()
{
    return 3347646682U;
}

void setval_405(unsigned *p)
{
    *p = 3277354225U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_440()
{
    return 3229929865U;
}

unsigned getval_353()
{
    return 2495777032U;
}

unsigned addval_378(unsigned x)
{
    return x + 3375940233U;
}

void setval_350(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_436()
{
    return 3281113481U;
}

void setval_167(unsigned *p)
{
    *p = 3286272360U;
}

void setval_229(unsigned *p)
{
    *p = 2797784713U;
}

void setval_491(unsigned *p)
{
    *p = 2425409161U;
}

void setval_464(unsigned *p)
{
    *p = 3685008009U;
}

void setval_468(unsigned *p)
{
    *p = 3677933961U;
}

void setval_318(unsigned *p)
{
    *p = 2497743176U;
}

void setval_211(unsigned *p)
{
    *p = 3383021961U;
}

unsigned addval_161(unsigned x)
{
    return x + 3286272328U;
}

void setval_128(unsigned *p)
{
    *p = 3374370441U;
}

unsigned getval_194()
{
    return 1321452161U;
}

unsigned getval_237()
{
    return 3529560457U;
}

void setval_208(unsigned *p)
{
    *p = 3676357129U;
}

unsigned addval_490(unsigned x)
{
    return x + 1388433033U;
}

unsigned getval_426()
{
    return 3767093412U;
}

unsigned addval_241(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_284()
{
    return 3378565513U;
}

unsigned getval_416()
{
    return 3523792553U;
}

unsigned addval_427(unsigned x)
{
    return x + 3286272330U;
}

unsigned addval_119(unsigned x)
{
    return x + 2425541001U;
}

unsigned addval_133(unsigned x)
{
    return x + 3247489673U;
}

void setval_352(unsigned *p)
{
    *p = 3676357257U;
}

void setval_255(unsigned *p)
{
    *p = 3525362305U;
}

unsigned addval_474(unsigned x)
{
    return x + 3674787464U;
}

void setval_351(unsigned *p)
{
    *p = 3682127497U;
}

unsigned getval_135()
{
    return 3285101013U;
}

unsigned addval_465(unsigned x)
{
    return x + 2425409801U;
}

void setval_431(unsigned *p)
{
    *p = 2497743176U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
